<template>
  <div id='footer'>
    <div class="content"></div>
  </div>
</template>
<script>
  export default {
    name:'Footer',
    components: {},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='sass' scoped>
@import './footer.scss'
</style>