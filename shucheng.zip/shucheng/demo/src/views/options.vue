<template>
  <div id=''>
    
  </div>
</template>
<script>
  export default {
    name:'Options',
    components: {},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='' scoped>

</style>