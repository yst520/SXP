<template>
  <div id='youxuan'>
    优选
  </div>
</template>
<script>
  export default {
    name:'Youxuan',
    components: {},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='' scoped>

</style>