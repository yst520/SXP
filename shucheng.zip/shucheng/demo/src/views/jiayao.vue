<template>
  <div id=''>
    jiyao 页面
  </div>
</template>
<script>
  export default {
    name:'Jiayao',
    components: {},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='' scoped>

</style>