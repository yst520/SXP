<template>
  <div id='shichi'>
    shichi
    <!-- <Footer/> -->
  </div>
</template>
<script>
import Footer from '../components/Footer.vue'
  export default {
    name:'Shichi',
    components: {Footer},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='' scoped>

</style>