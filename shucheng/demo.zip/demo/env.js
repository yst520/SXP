// 1.配置全局api地址
var baseUrl='http://localhost:10001'
// 2.导出
export default{
    baseUrl
}