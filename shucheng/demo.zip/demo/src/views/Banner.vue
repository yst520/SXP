<template>
  <div id='banner'>
    
  </div>
</template>
<script>
  export default {
    name:'Banner',
    components: {},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='' scoped>

</style>