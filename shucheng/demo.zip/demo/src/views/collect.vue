<template>
  <div id='collect'>
    收藏夹
  </div>
</template>
<script>
  export default {
    name:'Collect',
    components: {},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='' scoped>

</style>