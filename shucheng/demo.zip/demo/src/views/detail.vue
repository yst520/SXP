<template>
  <div id='detail'>
    <!-- 商品详情页 -->
    详情页
    <Gsearch />
  </div>
</template>
<script>
import Gsearch from "../components/Gsearch.vue";
  export default {
    name:'Deatil',
    components: {Gsearch},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='' scoped>

</style>