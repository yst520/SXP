<template>
  <div id="scene">
    <div class="container">
      <div class="classify" @mouseover="classifyBtn=true" @mouseout="classifyBtn=false">
        <span>全部分类</span>
        <!-- <div class="classify-detail" v-show="classifyBtn"> -->
        <div class="classify-detail" v-show="classifyBtn">
          <ul>
            <li v-for="(item,index) in menuList" :key="index" @click="toFruit(item)"> 
              <i :class="'item_icon'+index"></i>
              <p>{{item.text}}</p>
              <div><span>{{item.branch1}}</span><span>{{item.branch2}}</span><span>{{item.branch3}}</span></div>
            </li>
          </ul>
        </div>
      </div>
       
      <div class="scene-detail">
        <router-link to="/">首页</router-link>
        <router-link to="/youxuan">优选推荐</router-link>
        <router-link to="/tejia">当天特价</router-link>
        <router-link to="/shichi">鲜产试吃</router-link>
      </div>
      <!-- 品质保障 -->
      <div class="pinzhi">
        <i class="iconfont icon-zuanshi"></i>

        <span>品质保障</span>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Scene",
  components: {},
  props: [""],
  data() {
    return {
      classifyBtn:false,
      menuList:[
        {
          text:'新鲜水果',branch1:'草莓',branch2:'水蜜桃',branch3:'车厘子'
        },{
          text:'海鲜水产',branch1:'海鲜礼盒',branch2:'鱼类',branch3:'贝类'
        },{
          text:'精选肉类',branch1:'鸡翅',branch2:'猪肋排',branch3:'牛排'
        },{
          text:'冷饮冻食',branch1:'酸奶',branch2:'冰淇淋',branch3:'牛奶'
        },
        {
          text:'蔬菜蛋品',branch1:'水培蔬菜',branch2:'玉米',branch3:'蛋品'
        }
      ]
    };
  },
  created() {},
  methods: {
    toFruit(item){
      if(item.text == '新鲜水果'){
        this.$router.push({path:`/fruit/${item.text}`})
      }

    }
  },
};
</script>
<style lang='sass' scoped>
@import './scss/scene.scss'
</style>