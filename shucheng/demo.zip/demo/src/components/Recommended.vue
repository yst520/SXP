<template>
  <div id='recommended'>
    
  </div>
</template>
<script>
  export default {
    name:'Recommended',
    components: {},
    props:[''],
    data () {
      return {

      };
    },
    created() {},
    methods: {},
  }
</script>
<style lang='sass' scoped>
@import './scss/recommended.scss'
</style>